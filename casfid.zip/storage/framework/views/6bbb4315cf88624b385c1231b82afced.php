<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6 mb-4">
                <img src="<?php echo e($pizza->image_url); ?>" alt="<?php echo e($pizza->name); ?>" class="img-fluid rounded shadow">
            </div>
            <div class="col-12 col-lg-6">
                <h1 class="mb-3"><?php echo e($pizza->name); ?></h1>
                <p><strong><?php echo e(__('menu.price')); ?>: </strong><?php echo e($pizza->total_price->formatted); ?></p>

                <h4 class="mb-3"><?php echo e(__('menu.title_ingredients')); ?></h4>
                <ul class="list-group mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $pizza->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo e($ingredient->name); ?>

                            <span class="badge bg-primary"><?php echo e($ingredient->price->formatted); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item"><?php echo e(__('menu.no_ingredients')); ?></li>
                    <?php endif; ?>
                </ul>

                <div class="d-flex">
                    <a href="<?php echo e(route('pizzas.edit', $pizza->id)); ?>" class="btn btn-warning me-2"><?php echo e(__('menu.edit')); ?></a>
                    <form action="<?php echo e(route('pizzas.destroy', $pizza->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger"><?php echo e(__('menu.delete')); ?></button>
                    </form>
                </div>
            </div>
        </div>

        <a href="<?php echo e(route('pizzas.index')); ?>" class="btn btn-secondary mt-4"><?php echo e(__('menu.back_to_list')); ?></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/pizzas/show.blade.php ENDPATH**/ ?>