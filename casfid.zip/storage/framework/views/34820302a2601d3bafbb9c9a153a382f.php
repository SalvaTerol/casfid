<?php $__env->startSection('content'); ?>


    <div class="container">
        <h1><?php echo e(isset($pizza) ?  __('menu.edit_pizza') : __('menu.create_pizza')); ?></h1>
        <form action="<?php echo e(isset($pizza) ? route('pizzas.update', $pizza->id) : route('pizzas.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($pizza)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="mb-3">
                <label for="name" class="form-label"><?php echo e(__('menu.name')); ?></label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name', $pizza->name ?? '')); ?>" required>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label"><?php echo e(__('menu.image')); ?></label>
                <input type="file" name="image" class="form-control" id="image">
                <?php if(isset($pizza) && $pizza->image): ?>
                    <img src="<?php echo e($pizza->image_url); ?>" alt="<?php echo e($pizza->name); ?>" class="img-thumbnail mt-2" style="max-width: 150px;">
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="ingredients" class="form-label"><?php echo e(__('menu.title_ingredients')); ?></label>
                <select name="ingredients[]" id="ingredients" class="js-choice" multiple required>
                    <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ingredient->id); ?>"
                                <?php if(isset($pizza) && $pizza->ingredients->contains(fn($ing) => $ing->id === $ingredient->id)): ?> selected <?php endif; ?>>
                            <?php echo e($ingredient->name); ?> (<?php echo e($ingredient->price->formatted); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success"><?php echo e(isset($pizza) ? __('menu.update') : __('menu.create')); ?></button>
            <a href="<?php echo e(route('pizzas.index')); ?>" class="btn btn-secondary"><?php echo e(__('menu.cancel')); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/styles/choices.min.css"
    />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/scripts/choices.min.js"></script>
    <script type="text/javascript">
        const element = document.querySelector('.js-choice');
        const choices = new Choices(element);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/pizzas/form.blade.php ENDPATH**/ ?>