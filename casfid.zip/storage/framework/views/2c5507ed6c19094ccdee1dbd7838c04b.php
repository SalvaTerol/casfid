<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e(__('menu.title_pizzas')); ?></h1>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $viewModel->pizzas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-4 d-flex">
                    <div class="card h-100 d-flex flex-column">
                        <img src="<?php echo e($pizza->image_url); ?>" alt="<?php echo e($pizza->name); ?>" class="card-img-top">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo e($pizza->name); ?></h5>
                            <p class="card-text mb-2">
                                <strong><?php echo e(__('menu.price')); ?>:</strong> <?php echo e($pizza->total_price->formatted); ?>

                            </p>
                        </div>
                        <div class="card-footer flex-grow-1 d-flex flex-column">
                            <strong><?php echo e(__('menu.title_ingredients')); ?>:</strong>
                            <div class="d-flex">
                                <p class="mb-0">
                                    <?php $__currentLoopData = $pizza->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($ingredient->name); ?><?php if(!$loop->last): ?><?php echo e(","); ?><?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-warning"><?php echo e(__('menu.no_pizzas')); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php echo e($viewModel->pizzas()->links('components.pagination')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/home.blade.php ENDPATH**/ ?>