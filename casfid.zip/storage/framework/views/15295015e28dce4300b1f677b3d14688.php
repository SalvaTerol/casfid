<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6">
                <h1><?php echo e($ingredient->name); ?></h1>
                <p><strong><?php echo e(__('menu.price')); ?>:</strong> <?php echo e($ingredient->price->formatted); ?></p>

                <div class="d-flex">
                    <a href="<?php echo e(route('ingredients.edit', $ingredient->id)); ?>" class="btn btn-warning me-2"><?php echo e(__('menu.edit')); ?></a>
                    <form action="<?php echo e(route('ingredients.destroy', $ingredient->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger"><?php echo e(__('menu.delete')); ?></button>
                    </form>
                </div>
            </div>
        </div>

        <a href="<?php echo e(route('ingredients.index')); ?>" class="btn btn-secondary mt-4"><?php echo e(__('menu.back_to_list')); ?></a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/ingredients/show.blade.php ENDPATH**/ ?>