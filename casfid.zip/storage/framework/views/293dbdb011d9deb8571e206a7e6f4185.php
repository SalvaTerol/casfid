<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e(__('menu.title_pizzas')); ?></h1>
        <a href="<?php echo e(route('pizzas.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('menu.create_pizza')); ?></a>
        <table class="table table-hover">
            <thead>
            <tr>
                <th class="d-none d-lg-table-cell"></th>
                <th><?php echo e(__('menu.name')); ?></th>
                <th><?php echo e(__('menu.title_ingredients')); ?></th>
                <th><?php echo e(__('menu.price')); ?></th>
                <th><?php echo e(__('menu.actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $viewModel->pizzas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="d-none d-lg-table-cell"><img src="<?php echo e($pizza->image_url); ?>" alt="<?php echo e($pizza->name); ?>" class="rounded pizza-thumb"></td>
                    <td><?php echo e($pizza->name); ?></td>
                    <td>
                        <?php $__currentLoopData = $pizza->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($ingredient->name); ?> (<?php echo e($ingredient->price->formatted); ?>)<?php if(!$loop->last): ?><?php echo e(","); ?><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($pizza->total_price->formatted); ?></td>
                    <td>
                        <div class="d-flex flex-column">
                            <a href="<?php echo e(route('pizzas.edit', $pizza->id)); ?>" class="btn btn-warning mb-2 w-100"><?php echo e(__('menu.edit')); ?></a>
                            <form action="<?php echo e(route('pizzas.destroy', $pizza->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger w-100"><?php echo e(__('menu.delete')); ?></button>
                            </form>
                        </div>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4"><?php echo e(__('menu.no_pizzas')); ?></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($viewModel->pizzas()->links('components.pagination')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/pizzas/index.blade.php ENDPATH**/ ?>