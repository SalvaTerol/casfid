<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1><?php echo e(__('menu.title_ingredients')); ?></h1>
        <a href="<?php echo e(route('ingredients.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('menu.create_ingredient')); ?></a>
        <table class="table">
            <thead>
            <tr>
                <th><?php echo e(__('menu.name')); ?></th>
                <th><?php echo e(__('menu.price')); ?></th>
                <th><?php echo e(__('menu.actions')); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $viewModel->ingredients(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ingredient->name); ?></td>
                    <td><?php echo e($ingredient->price->formatted); ?></td>
                    <td>
                        <a href="<?php echo e(route('ingredients.edit', $ingredient->id)); ?>" class="btn btn-warning"><?php echo e(__('menu.edit')); ?></a>
                        <form action="<?php echo e(route('ingredients.destroy', $ingredient->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger"><?php echo e(__('menu.delete')); ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($viewModel->ingredients()->links('components.pagination')); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casfid\resources\views/ingredients/index.blade.php ENDPATH**/ ?>